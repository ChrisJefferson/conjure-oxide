// Minion https://github.com/minion/minion
// SPDX-License-Identifier: MPL-2.0

// This file just defines all global variables, using "IN_MAIN"

// These are just because VC++ sucks.
#define _CRT_SECURE_NO_DEPRECATE 1
#define _CRT_NONSTDC_NO_DEPRECATE 1

#ifndef IN_MAIN
#define IN_MAIN
#endif

#include "globals.h"
#include "minion.h"

#include "constraint_defs.h"
#include "triggering/dynamic_trigger.h"

#ifdef LIBMINION
thread_local Globals* globals = nullptr;
thread_local DynamicTriggerList globalNullTriggerList;
#else
DynamicTriggerList globalNullTriggerList;
#endif

SysInt numOfConstraints = sizeof(constraint_list) / sizeof(ConstraintDef);

std::ostream& getOutput() {
#ifdef LIBMINION
  // Fall back to std::cout when no context is active: command-line
  // parsing, --help and the standalone tools all print before (and
  // after) any Globals exists.
  if(!globals || !globals->out_m)
    return std::cout;
  return *globals->out_m;
#else
  return std::cout;
#endif
}

Globals::Globals() {
    searchMem_m = NULL;
    options_m = NULL;
    state_m = NULL;
    queues_m = NULL;
    varContainer_m = NULL;
    bools_m = NULL;
    parData_m = NULL;
    tableOut_m = NULL;
    callback = NULL;
    callbackUserdata = NULL;
    out_m = &std::cout;
}

#ifdef LIBMINION
TableOut& getTableOut() {
  if(!globals->tableOut_m) {
    globals->tableOut_m = new TableOut();
  }
  return *globals->tableOut_m;
}
#endif

Globals::~Globals() {
  delete this->bools_m;
  delete this->state_m;
  delete this->queues_m;
  delete this->options_m;
  // No parallel minion in library usage for now
  //delete this->parData_m; //FIXME: having this in causes runMinion to segfault!
  delete this->varContainer_m;
  delete this->searchMem_m;
  delete this->tableOut_m;
}
